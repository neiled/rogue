#ifndef GLOBALHPP
#define GLOBALHPP

template<typename T>
unsigned int ngl::Geometry<T>::D;

#endif
